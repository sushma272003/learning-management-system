"use client"
import SignupFormDemo from '@/components/example/signup-form-demo'
import React from 'react'

const page = () => {
  return (
    <div>
        <SignupFormDemo />
    </div>
  )
}

export default page