"use client";
import { TextGenerateEffect } from "@/components/ui/text-generate-effect";

const words = `Welcome to Your Dashboard — Track Progress, Take Charge, and Achieve More!`;

export function TextGenerateEffectDemo() {
  return <TextGenerateEffect words={words} />;
}
